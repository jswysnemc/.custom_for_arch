return {
    {
        "HiPhish/rainbow-delimiters.nvim",
    }
}
